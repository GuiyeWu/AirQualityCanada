package airQC;

public class Search<Key extends Comparable<Key>, Value> {

	private Key[] keys;

	private Value[] vals;

	private int N;

	public Search(int capacity) {
	}

	public int size()

	{
		return N;
	}

	public Value get(Key key) {

		if (isEmpty())
			return null;

		int i = rank(key);

		if (i < N && keys[i].compareTo(key) == 0)
			return vals[i];

		else
			return null;
	}

	public int rank(Key key) {

		int lo = 0, hi = N - 1;

		while (lo <= hi) {

			int mid = lo + (hi - lo) / 2;

			int cmp = key.compareTo(keys[mid]);

			if (cmp < 0)
				hi = mid - 1;

			else if (cmp > 0)
				lo = mid + 1;

			else
				return mid;

		}

		return lo;
	}

	//public void put(Key key, Value val) {
	//}

	//public void delete(Key key) {
	//}

	//public boolean isEmpty() {
	//}
}
