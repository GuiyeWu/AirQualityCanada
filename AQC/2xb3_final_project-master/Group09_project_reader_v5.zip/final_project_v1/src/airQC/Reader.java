package airQC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.LineNumberReader;
import java.net.URL;

public class Reader {
	public static void main(String[] args) throws FileNotFoundException {
		/*try{
			URL url = new URL("dd.weather.gc.ca/air_quality/aqhi/pnr/observation/monthly/csv/201702_MONTHLY_AQHI_PNR_SiteObs.csv");
		}
		catch(IOException e){
			e.printStackTrace();
		}*/
		File file = new File(
				"/home/michelle/Downloads/2XB3_Project/2018030606_AQHI_ATL_SiteObs.csv");
		Scanner sc = new Scanner(file);

		sc.useDelimiter(",");
		String firstLine = new String(sc.nextLine());
		String[] firstLineArr = firstLine.split(",");

		String[] labelsArr = new String[firstLine.length() - 2];
		for (int i = 2; i < firstLineArr.length; i++) {
			labelsArr[i - 2] = firstLineArr[i];
			//System.out.println(labelsArr[i - 2]);
		}
		
		int count = 0;
		while (sc.hasNextLine()) {
			count++;
			sc.nextLine();
			//System.out.println(sc.nextLine());
		}
		//System.out.println("The number of rows: " + count);
		sc.close();
		
		//String[][] data = new String[labelsArr.length][count+1];
		String[][] data = new String[labelsArr.length-2][count+1]; // Did not count the first row
		for (int i = 0; i < labelsArr.length-2; i++) //removing the first two elements (Data, Hour)
			data[i][0] = labelsArr[i+2];
		System.out.println("This is labelsArr length: "+ labelsArr.length);
		Scanner sc1 = new Scanner(file);
		sc1.nextLine();
		String [] nextDataLine = new String[firstLineArr.length];
		for (int j = 1; j < count+1; j++) {
			nextDataLine = sc1.nextLine().split(",");
			for (int i = 0; i < firstLineArr.length-2;i++ ){
				data[i][j] = nextDataLine[i+2];
				//System.out.println(data[i][j]);
			}
		}
		System.out.println("This is firstLineArr length: " + firstLineArr.length);
		//System.out.println(data[0][25]);
		sc1.close();
		for(int i = 0; i < firstLineArr.length-2; i++)
			for(int j = 0; j < count+1; j++)
				System.out.println(data[i][j]);
	}
}