package airQC;

public class NodeADT {
	private String city;
	private String color;
	private double index;
	
	public NodeADT(String city, String color,double index) {
		city = this.city;
		color = this.color;
		index = this.index;
	}
	
	public String getCity() {
		return city;
	}
	
	public String getColor() {
		return color;
	}
	
	public double getIndex() {
		return index;
	}
	
	

}
