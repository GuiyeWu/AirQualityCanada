package airQC;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Load {

	/*public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(new BufferedInputStream(System.in));
		System.out.println("Type the file name:");
		String file = input.next();
		System.out.println("Type the number of cities in this file");
		int N = input.nextInt();
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String[][] data = new String[N][];
		/*
		 * Skipping: Store the file information into data as the form:[[city23, index,
		 * index,��], [city13, index, index, ��], ��]
		 */
		//String[][] data2 = new String[N][];
		//double[] totIndex = new double[data.length];
		/*NodeADT[] nodes = new NodeADT[data.length];
		for (int i = 0; i < data.length; i++) {
			double[] index = new double[data[i].length - 1];
			index = IndexArray(data[i]);
			double index1;
			index1 = AverageCalculator(index);
			//totIndex[i] = index1;
			String color;
			color = Color(index1);
			//data2[i][0] = data[i][0];
			//data2[i][1] = color;
			nodes[i] = new NodeADT(data[i][0],color,index1);
		}
		
	}*/
/*
	private static String Color(double index) {
		String color = "SOMETHING WRONG";

		if (0 <= index && index < 1.5)
			color = "LightBlue";
		else if (1.5 <= index && index < 2.5)
			color = "RoyalBlue";
		else if (2.5 <= index && index < 3.5)
			color = "MediumBlue";
		else if (3.5 <= index && index < 4.5)
			color = "Yellow";
		else if (4.5 <= index && index < 5.5)
			color = "Gold";
		else if (5.5 <= index && index < 6.5)
			color = "Orange";
		else if (6.5 <= index && index < 7.5)
			color = "Violet";
		else if (7.5 <= index && index < 8.5)
			color = "Red";
		else if (8.5 <= index && index < 9.5)
			color = "Crimson";
		else if (9.5 <= index && index < 10.5)
			color = "FireBrick";
		else if (10.5 <= index)
			color = "DarkRed";

		return color;
	}

	private static double AverageCalculator(double[] index) {
		double avg = 0.0;
		for (int i = 0; i < index.length; i++) {
			avg += index[i];
		}
		avg = avg / index.length;
		return avg;
	}

	private static double[] IndexArray(String[] s) {
		double[] index = new double[s.length - 1];
		for (int i = 0; i < s.length - 1; i++) {
			index[i] = Double.parseDouble(s[i + 1]);
		}
		return index;
	}

	private static void sort(NodeADT[] nodes) {
		Heapsort.sortHeap(nodes, nodes.length);
	}

}*/
