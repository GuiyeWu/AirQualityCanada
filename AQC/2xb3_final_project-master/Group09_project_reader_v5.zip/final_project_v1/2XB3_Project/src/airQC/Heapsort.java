package airQC;

public class Heapsort {
	public static void sortHeap ( NodeADT[] x, int n ) {
		for (int k = n/2; k >= 1; k--)
			sink(x,k,n);
		while (n > 1) {
			NodeADT t = x[0];
			x[0] = x[n-1];
			x[n-1] = t;
			n--;
			sink(x,1,n);
		}
	}
	private static void sink(NodeADT[] x, int k,int n) {
		while (2*k <= n) {
			int j = 2*k;
			if (j < n && x[j-1].getCity().compareTo(x[j].getCity())<0)
				j++;
			if (x[k-1].getCity().compareTo(x[j-1].getCity())>=0)
				break;
			NodeADT t = x[k-1];
			x[k-1] = x[j-1];
			x[j-1] = t;
			k = j;
		}
	}
}
